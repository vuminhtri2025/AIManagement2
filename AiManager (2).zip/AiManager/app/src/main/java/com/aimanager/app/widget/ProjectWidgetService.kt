package com.aimanager.app.widget

import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.widget.RemoteViews
import android.widget.RemoteViewsService
import com.aimanager.app.Consts
import com.aimanager.app.R
import com.aimanager.app.data.Project
import com.aimanager.app.data.Store
import com.aimanager.app.ui.aiLabel
import com.aimanager.app.ui.fmtRemaining

class ProjectWidgetService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsService.RemoteViewsFactory {
        val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        return Factory(applicationContext, id)
    }

    private class Factory(
        private val ctx: Context,
        private val widgetId: Int
    ) : RemoteViewsService.RemoteViewsFactory {
        private var items: List<Project> = emptyList()
        private var fillerPx: Int = 0

        override fun onCreate() {}

        override fun onDataSetChanged() {
            val now = System.currentTimeMillis()
            items = Store.load(ctx)
                .filter { !it.isDone }
                .sortedWith(
                    compareBy<Project>(
                        { if (it.isCooling(now)) 0 else 1 },
                        { if (it.isCooling(now)) it.cooldownUntil else 0L },
                        { it.name.lowercase() }
                    )
                )
            fillerPx = computeFiller()
        }

        /**
         * ListView trong widget không nhận cú chạm ở vùng trống bên dưới các dòng.
         * Thêm 1 dòng "đệm" trong suốt lấp đầy phần còn trống để bấm vào đó mở trang chủ dự án.
         */
        private fun computeFiller(): Int {
            if (items.isEmpty() || widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) return 0
            val opts = AppWidgetManager.getInstance(ctx).getAppWidgetOptions(widgetId)
            val landscape = ctx.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
            val heightDp = if (landscape) {
                opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0)
            } else {
                opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
            }
            if (heightDp <= 0) return 0
            val listDp = heightDp - 56          // trừ padding + dòng tiêu đề
            val fillDp = listDp - items.size * 70 - 6
            if (fillDp <= 8) return 0
            return (fillDp * ctx.resources.displayMetrics.density).toInt()
        }

        override fun onDestroy() {}

        override fun getCount(): Int =
            if (items.isEmpty()) 0 else items.size + (if (fillerPx > 0) 1 else 0)

        override fun getViewAt(position: Int): RemoteViews {
            if (position >= items.size) {
                val filler = RemoteViews(ctx.packageName, R.layout.widget_filler)
                filler.setViewPadding(R.id.filler_root, 0, fillerPx, 0, 0)
                filler.setOnClickFillInIntent(
                    R.id.filler_root,
                    Intent().putExtra(Consts.EXTRA_TAB, 0)
                )
                return filler
            }
            val rv = RemoteViews(ctx.packageName, R.layout.widget_item)
            val p = items[position]
            val now = System.currentTimeMillis()
            rv.setTextViewText(R.id.item_name, p.name)
            rv.setTextViewText(R.id.item_ai, "${aiLabel(p.ai)} · còn ${p.remaining} việc")
            if (p.isCooling(now)) {
                rv.setTextViewText(R.id.item_status, "Đang hồi · còn ${fmtRemaining(p.cooldownUntil, now)}")
                rv.setTextColor(R.id.item_status, Color.parseColor("#FFD166"))
            } else {
                rv.setTextViewText(R.id.item_status, "Sẵn sàng")
                rv.setTextColor(R.id.item_status, Color.parseColor("#86EFAC"))
            }
            rv.setOnClickFillInIntent(
                R.id.item_root,
                Intent().putExtra(Consts.EXTRA_PROJECT_ID, p.id)
            )
            return rv
        }

        override fun getLoadingView(): RemoteViews? = null
        override fun getViewTypeCount(): Int = 2
        override fun getItemId(position: Int): Long =
            items.getOrNull(position)?.id?.hashCode()?.toLong() ?: (Long.MAX_VALUE - position)
        override fun hasStableIds(): Boolean = true
    }
}
