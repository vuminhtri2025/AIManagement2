package com.aimanager.app.data

import android.content.Context
import org.json.JSONArray

object Store {
    private const val PREF = "ai_manager_store"
    private const val KEY = "projects"
    private const val KEY_AIS = "ais"

    fun load(ctx: Context): List<Project> {
        val raw = ctx.applicationContext
            .getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getString(KEY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { arr.getJSONObject(it).toProject() }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(ctx: Context, projects: List<Project>) {
        val arr = JSONArray()
        projects.forEach { arr.put(it.toJson()) }
        ctx.applicationContext
            .getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY, arr.toString())
            .apply()
    }

    /** Danh sách AI do người dùng tự thêm (gộp thêm AI đang được dự án dùng, nếu có). */
    fun loadAis(ctx: Context, projects: List<Project>): List<String> {
        val raw = ctx.applicationContext
            .getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getString(KEY_AIS, null)
        val result = mutableListOf<String>()
        if (raw != null) {
            try {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val n = arr.getString(i).trim()
                    if (n.isNotEmpty() && result.none { it.equals(n, ignoreCase = true) }) result.add(n)
                }
            } catch (e: Exception) {
                // bỏ qua dữ liệu hỏng
            }
        }
        for (p in projects) {
            val n = p.ai.trim()
            if (n.isNotEmpty() && result.none { it.equals(n, ignoreCase = true) }) result.add(n)
        }
        return result
    }

    fun saveAis(ctx: Context, ais: List<String>) {
        val arr = JSONArray()
        ais.forEach { arr.put(it) }
        ctx.applicationContext
            .getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_AIS, arr.toString())
            .apply()
    }
}
