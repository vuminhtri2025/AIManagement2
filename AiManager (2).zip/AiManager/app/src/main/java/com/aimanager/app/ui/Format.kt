package com.aimanager.app.ui

import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

private val timeFmt = DateTimeFormatter.ofPattern("HH:mm")
private val dayFmt = DateTimeFormatter.ofPattern("dd/MM")
private val fullDayFmt = DateTimeFormatter.ofPattern("dd/MM/yyyy")
private val dateTimeFmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")

fun zoned(ms: Long): ZonedDateTime = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault())

fun fmtTime(ms: Long): String = zoned(ms).format(timeFmt)
fun fmtFullDate(ms: Long): String = zoned(ms).format(fullDayFmt)
fun fmtDateTime(ms: Long): String = zoned(ms).format(dateTimeFmt)

/** Chỉ giờ:phút (không giây). Khác ngày hôm nay thì thêm ngày/tháng. */
fun fmtCooldown(ms: Long, now: Long): String {
    val d = zoned(ms)
    val sameDay = d.toLocalDate() == zoned(now).toLocalDate()
    return if (sameDay) d.format(timeFmt) else d.format(timeFmt) + " · " + d.format(dayFmt)
}

fun fmtRemaining(ms: Long, now: Long): String {
    val mins = (ms - now + 59_999L) / 60_000L
    if (mins <= 0) return "0p"
    val days = mins / (60 * 24)
    val hours = (mins / 60) % 24
    val m = mins % 60
    return when {
        days > 0 -> "${days}n ${hours}g"
        hours > 0 -> "${hours}g ${m}p"
        else -> "${m}p"
    }
}

fun aiLabel(ai: String): String = ai.ifBlank { "Chưa chọn AI" }
