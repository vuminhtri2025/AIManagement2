package com.aimanager.app

object Consts {
    const val ACTION_OPEN_PROJECT = "com.aimanager.app.OPEN_PROJECT"
    const val ACTION_OPEN_TAB = "com.aimanager.app.OPEN_TAB"
    const val ACTION_AI_READY = "com.aimanager.app.AI_READY"
    const val EXTRA_PROJECT_ID = "project_id"
    const val EXTRA_TAB = "tab"
    const val SOUND_SILENT = "silent"
}
