package com.aimanager.app

import android.app.Application
import android.content.Context
import android.content.Intent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.aimanager.app.data.Ai
import com.aimanager.app.data.Project
import com.aimanager.app.data.Store
import com.aimanager.app.data.Todo
import com.aimanager.app.widget.ProjectWidgetProvider

/** Đang mở màn hình nhập công việc: todoId = null nghĩa là công việc mới. */
data class TodoTarget(val projectId: String, val todoId: String?)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Context get() = getApplication<Application>().applicationContext

    private val initialProjects: List<Project> = Store.load(app)

    var projects by mutableStateOf(initialProjects)
        private set
    /** Danh sách AI do người dùng tự thêm (kèm trạng thái hồi) */
    var ais by mutableStateOf(Store.loadAis(app, initialProjects))
        private set

    /** Tên AI đang mở trang chi tiết */
    var openAi by mutableStateOf<String?>(null)
    var openProjectId by mutableStateOf<String?>(null)
    var todoEditor by mutableStateOf<TodoTarget?>(null)
    var requestedTab by mutableStateOf<Int?>(null)

    fun aiOf(name: String): Ai? = if (name.isBlank()) null else ais.firstOrNull { it.name == name }

    private fun commit(list: List<Project>, newAis: List<Ai> = ais) {
        projects = list
        ais = newAis
        Store.save(ctx, list)
        Store.saveAis(ctx, newAis)
        ProjectWidgetProvider.updateAll(ctx)
    }

    private fun change(id: String, f: (Project) -> Project) {
        commit(projects.map { p -> if (p.id == id) f(p) else p })
    }

    // ------------------------------------------------ Dự án

    fun addProject(name: String): String {
        val p = Project(
            name = name.trim().ifBlank { "Dự án mới" },
            ai = ais.firstOrNull()?.name ?: ""
        )
        commit(listOf(p) + projects)
        return p.id
    }

    fun rename(id: String, name: String) {
        if (name.isBlank()) return
        change(id) { it.copy(name = name.trim()) }
    }

    fun delete(id: String) {
        commit(projects.filterNot { it.id == id })
        if (openProjectId == id) openProjectId = null
    }

    /** Gán AI cho dự án; nếu tên AI chưa có trong danh sách thì thêm mới. */
    fun assignAi(projectId: String, name: String) {
        val n = name.trim()
        if (n.isEmpty()) return
        val existing = ais.firstOrNull { it.name.equals(n, ignoreCase = true) }
        if (existing == null) {
            commit(projects.map { if (it.id == projectId) it.copy(ai = n) else it }, ais + Ai(name = n))
        } else {
            change(projectId) { it.copy(ai = existing.name) }
        }
    }

    fun setSound(id: String, uri: String, name: String) {
        change(id) { it.copy(soundUri = uri, soundName = name) }
    }

    // ------------------------------------------------ AI

    /** @return false nếu tên rỗng hoặc đã tồn tại */
    fun addAi(name: String): Boolean {
        val n = name.trim()
        if (n.isEmpty() || ais.any { it.name.equals(n, ignoreCase = true) }) return false
        commit(projects, ais + Ai(name = n))
        return true
    }

    /** @return false nếu tên rỗng hoặc trùng với AI khác */
    fun renameAi(old: String, newName: String): Boolean {
        val n = newName.trim()
        if (n.isEmpty()) return false
        if (ais.any { it.name != old && it.name.equals(n, ignoreCase = true) }) return false
        commit(
            projects.map { if (it.ai == old) it.copy(ai = n) else it },
            ais.map { if (it.name == old) it.copy(name = n) else it }
        )
        if (openAi == old) openAi = n
        return true
    }

    /** Xóa AI; các dự án đang dùng AI này chuyển về "chưa chọn AI". */
    fun deleteAi(name: String) {
        val target = aiOf(name)
        if (target != null) Alarms.cancel(ctx, target.id)
        commit(
            projects.map { if (it.ai == name) it.copy(ai = "") else it },
            ais.filterNot { it.name == name }
        )
        if (openAi == name) openAi = null
    }

    /** millis = 0 -> sẵn sàng; > now -> đang hồi tới thời điểm đó. Dùng chung cho mọi dự án của AI. */
    fun setAiCooldown(name: String, millis: Long) {
        val target = aiOf(name) ?: return
        val updated = target.copy(cooldownUntil = millis)
        commit(projects, ais.map { if (it.id == target.id) updated else it })
        Alarms.schedule(ctx, updated)
    }

    // ------------------------------------------------ Todo

    fun openTodoEditor(projectId: String, todoId: String?) {
        todoEditor = TodoTarget(projectId, todoId)
    }

    fun closeTodoEditor() {
        todoEditor = null
    }

    /** Lưu công việc (todoId = null -> tạo mới ở đầu danh sách). */
    fun saveTodo(projectId: String, todoId: String?, title: String, note: String) {
        val t0 = title.trim()
        val n = note.trim()
        if (t0.isEmpty() && n.isEmpty()) return
        val t = t0.ifEmpty { n.lineSequence().first().take(80) }
        if (todoId == null) {
            change(projectId) { it.copy(todos = listOf(Todo(text = t, note = n)) + it.todos) }
        } else {
            change(projectId) { p ->
                p.copy(todos = p.todos.map { if (it.id == todoId) it.copy(text = t, note = n) else it })
            }
        }
    }

    fun toggleTodo(id: String, todoId: String) {
        change(id) { p ->
            p.copy(todos = p.todos.map { if (it.id == todoId) it.copy(done = !it.done) else it })
        }
    }

    fun deleteTodo(id: String, todoId: String) {
        change(id) { p -> p.copy(todos = p.todos.filterNot { it.id == todoId }) }
    }

    // ------------------------------------------------ Intent (widget, thông báo)

    fun handleIntent(intent: Intent?) {
        intent ?: return
        when (intent.action) {
            Consts.ACTION_OPEN_PROJECT -> {
                todoEditor = null
                openAi = null
                val id = intent.getStringExtra(Consts.EXTRA_PROJECT_ID)
                if (id != null && projects.any { it.id == id }) {
                    openProjectId = id
                } else {
                    // bấm vùng trống của widget -> trang chủ dự án
                    openProjectId = null
                    requestedTab = 0
                }
            }
            Consts.ACTION_OPEN_AI -> {
                todoEditor = null
                openProjectId = null
                val id = intent.getStringExtra(Consts.EXTRA_AI_ID)
                val ai = ais.firstOrNull { it.id == id }
                if (ai != null) {
                    openAi = ai.name
                } else {
                    openAi = null
                    requestedTab = 1
                }
            }
            Consts.ACTION_OPEN_TAB -> {
                todoEditor = null
                openAi = null
                openProjectId = null
                requestedTab = intent.getIntExtra(Consts.EXTRA_TAB, 0)
            }
        }
    }
}
