package com.aimanager.app.widget

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.widget.RemoteViews
import android.widget.RemoteViewsService
import com.aimanager.app.Consts
import com.aimanager.app.R
import com.aimanager.app.data.Project
import com.aimanager.app.data.Store
import com.aimanager.app.ui.fmtCooldown
import com.aimanager.app.ui.fmtRemaining

class ProjectWidgetService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsService.RemoteViewsFactory = Factory(applicationContext)

    private class Factory(private val ctx: Context) : RemoteViewsService.RemoteViewsFactory {
        private var items: List<Project> = emptyList()

        override fun onCreate() {}

        override fun onDataSetChanged() {
            val now = System.currentTimeMillis()
            items = Store.load(ctx)
                .filter { !it.isDone }
                .sortedWith(
                    compareBy<Project>(
                        { if (it.isCooling(now)) 0 else 1 },
                        { if (it.isCooling(now)) it.cooldownUntil else 0L },
                        { it.name.lowercase() }
                    )
                )
        }

        override fun onDestroy() {}

        override fun getCount(): Int = items.size

        override fun getViewAt(position: Int): RemoteViews {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_item)
            val p = items.getOrNull(position) ?: return rv
            val now = System.currentTimeMillis()
            rv.setTextViewText(R.id.item_name, p.name)
            rv.setTextViewText(R.id.item_ai, "${p.ai} · còn ${p.remaining} việc")
            if (p.isCooling(now)) {
                rv.setTextViewText(
                    R.id.item_status,
                    "Hồi ${fmtCooldown(p.cooldownUntil, now)} · còn ${fmtRemaining(p.cooldownUntil, now)}"
                )
                rv.setTextColor(R.id.item_status, Color.parseColor("#FB923C"))
            } else {
                rv.setTextViewText(R.id.item_status, "Sẵn sàng")
                rv.setTextColor(R.id.item_status, Color.parseColor("#4ADE80"))
            }
            rv.setOnClickFillInIntent(
                R.id.item_root,
                Intent().putExtra(Consts.EXTRA_PROJECT_ID, p.id)
            )
            return rv
        }

        override fun getLoadingView(): RemoteViews? = null
        override fun getViewTypeCount(): Int = 1
        override fun getItemId(position: Int): Long = items.getOrNull(position)?.id?.hashCode()?.toLong() ?: position.toLong()
        override fun hasStableIds(): Boolean = true
    }
}
