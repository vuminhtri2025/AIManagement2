@file:OptIn(ExperimentalMaterial3Api::class)

package com.aimanager.app.ui

import android.content.Context
import android.media.Ringtone
import android.media.RingtoneManager
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.aimanager.app.AppViewModel
import com.aimanager.app.Consts
import com.aimanager.app.Notifier
import com.aimanager.app.data.Project

@Composable
fun NameDialog(
    title: String,
    initial: String,
    confirmText: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var text by remember { mutableStateOf(initial) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                placeholder = { Text("Tên dự án") },
                shape = RoundedCornerShape(14.dp),
                colors = fieldColors(),
                modifier = Modifier.focusRequester(focus)
            )
        },
        confirmButton = {
            TextButton(onClick = { if (text.isNotBlank()) onConfirm(text.trim()) }) { Text(confirmText) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Hủy") } }
    )
}

@Composable
fun ConfirmDialog(
    title: String,
    message: String,
    confirmText: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(message, color = AppColors.Muted) },
        confirmButton = {
            TextButton(onClick = onConfirm) { Text(confirmText, color = AppColors.Red) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Hủy") } }
    )
}

data class SoundOption(val name: String, val uri: String)

fun loadSounds(ctx: Context): List<SoundOption> {
    val list = mutableListOf(
        SoundOption("Mặc định", ""),
        SoundOption("Im lặng", Consts.SOUND_SILENT)
    )
    for (type in listOf(RingtoneManager.TYPE_NOTIFICATION, RingtoneManager.TYPE_ALARM)) {
        try {
            val rm = RingtoneManager(ctx)
            rm.setType(type)
            val c = rm.cursor
            try {
                while (c.moveToNext()) {
                    val title = c.getString(RingtoneManager.TITLE_COLUMN_INDEX) ?: continue
                    val uri = rm.getRingtoneUri(c.position).toString()
                    if (list.none { it.uri == uri }) list.add(SoundOption(title, uri))
                }
            } finally {
                c.close()
            }
        } catch (e: Exception) {
            // thiết bị không cho liệt kê chuông -> chỉ dùng mặc định / im lặng
        }
    }
    return list
}

@Composable
fun SoundDialog(currentUri: String, onSave: (SoundOption) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val options = remember { loadSounds(ctx) }
    var selected by remember { mutableStateOf(options.firstOrNull { it.uri == currentUri } ?: options.first()) }
    var player by remember { mutableStateOf<Ringtone?>(null) }

    DisposableEffect(Unit) { onDispose { player?.stop() } }

    fun preview(o: SoundOption) {
        player?.stop()
        player = null
        val uri = Notifier.resolveSound(o.uri) ?: return
        player = RingtoneManager.getRingtone(ctx, uri)?.also { it.play() }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Chuông báo") },
        text = {
            LazyColumn(Modifier.heightIn(max = 340.dp)) {
                items(options, key = { it.uri }) { o ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable {
                                selected = o
                                preview(o)
                            }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = o.uri == selected.uri, onClick = null)
                        Spacer(Modifier.width(12.dp))
                        Text(o.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                player?.stop()
                onSave(selected)
            }) { Text("Lưu") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Hủy") } }
    )
}

@Composable
fun AiPickerDialog(
    current: String,
    options: List<String>,
    onPick: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var custom by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Chọn AI") },
        text = {
            Column {
                LazyColumn(Modifier.heightIn(max = 260.dp)) {
                    items(options, key = { it }) { name ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { onPick(name) }
                                .padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = name == current, onClick = null)
                            Spacer(Modifier.width(12.dp))
                            Text(name)
                        }
                    }
                }
                OutlinedTextField(
                    value = custom,
                    onValueChange = { custom = it },
                    singleLine = true,
                    placeholder = { Text("AI khác…") },
                    shape = RoundedCornerShape(14.dp),
                    colors = fieldColors(),
                    trailingIcon = {
                        IconButton(onClick = { if (custom.isNotBlank()) onPick(custom.trim()) }) {
                            Icon(Icons.Default.Check, contentDescription = "Thêm", tint = Color.White)
                        }
                    },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                )
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Đóng") } }
    )
}

/** Bảng chọn giờ dạng đồng hồ kim, kéo để chọn giờ rồi phút. */
@Composable
fun ClockTimeDialog(
    initialHour: Int,
    initialMinute: Int,
    onConfirm: (hour: Int, minute: Int) -> Unit,
    onDismiss: () -> Unit
) {
    val state = rememberTimePickerState(
        initialHour = initialHour,
        initialMinute = initialMinute,
        is24Hour = true
    )
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            modifier = Modifier.padding(16.dp)
        ) {
            Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    "Chọn giờ hồi",
                    color = AppColors.Muted,
                    modifier = Modifier
                        .align(Alignment.Start)
                        .padding(bottom = 20.dp)
                )
                TimePicker(state = state)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Hủy") }
                    TextButton(onClick = { onConfirm(state.hour, state.minute) }) { Text("Chọn") }
                }
            }
        }
    }
}

private enum class MenuDialog { Rename, Sound, Delete }

/** Nút 3 chấm: đổi tên dự án, chuông báo, xóa dự án. */
@Composable
fun ProjectMenuButton(project: Project, vm: AppViewModel, onDeleted: () -> Unit = {}) {
    var expanded by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf<MenuDialog?>(null) }

    Box {
        IconButton(onClick = { expanded = true }) {
            Icon(Icons.Default.MoreVert, contentDescription = "Tùy chọn", tint = AppColors.Muted)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            DropdownMenuItem(
                text = { Text("Đổi tên dự án") },
                onClick = { expanded = false; dialog = MenuDialog.Rename }
            )
            DropdownMenuItem(
                text = { Text("Chuông báo: ${project.soundName}") },
                onClick = { expanded = false; dialog = MenuDialog.Sound }
            )
            DropdownMenuItem(
                text = { Text("Xóa dự án", color = AppColors.Red) },
                onClick = { expanded = false; dialog = MenuDialog.Delete }
            )
        }
    }

    when (dialog) {
        MenuDialog.Rename -> NameDialog(
            title = "Đổi tên dự án",
            initial = project.name,
            confirmText = "Lưu",
            onConfirm = { vm.rename(project.id, it); dialog = null },
            onDismiss = { dialog = null }
        )
        MenuDialog.Sound -> SoundDialog(
            currentUri = project.soundUri,
            onSave = { vm.setSound(project.id, it.uri, it.name); dialog = null },
            onDismiss = { dialog = null }
        )
        MenuDialog.Delete -> ConfirmDialog(
            title = "Xóa dự án?",
            message = "Dự án \"${project.name}\" và toàn bộ todolist sẽ bị xóa.",
            confirmText = "Xóa",
            onConfirm = { dialog = null; vm.delete(project.id); onDeleted() },
            onDismiss = { dialog = null }
        )
        null -> {}
    }
}
