package com.aimanager.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import android.provider.Settings
import com.aimanager.app.data.Project
import com.aimanager.app.data.Store
import com.aimanager.app.widget.ProjectWidgetProvider

object Alarms {
    fun schedule(ctx: Context, p: Project) {
        val app = ctx.applicationContext
        cancel(app, p.id)
        if (p.cooldownUntil <= System.currentTimeMillis()) return
        val am = app.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pendingFor(app, p.id)
        try {
            val canExact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()
            if (canExact) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, p.cooldownUntil, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, p.cooldownUntil, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, p.cooldownUntil, pi)
        }
    }

    fun cancel(ctx: Context, projectId: String) {
        val app = ctx.applicationContext
        val am = app.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pendingFor(app, projectId))
    }

    fun rescheduleAll(ctx: Context, projects: List<Project>) {
        projects.forEach { schedule(ctx, it) }
    }

    private fun pendingFor(ctx: Context, projectId: String): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java)
            .setAction(Consts.ACTION_AI_READY)
            .putExtra(Consts.EXTRA_PROJECT_ID, projectId)
        return PendingIntent.getBroadcast(
            ctx,
            projectId.hashCode(),
            i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}

object Notifier {
    fun resolveSound(uri: String): Uri? = when (uri) {
        Consts.SOUND_SILENT -> null
        "" -> Settings.System.DEFAULT_NOTIFICATION_URI
        else -> Uri.parse(uri)
    }

    private fun ensureChannel(ctx: Context, p: Project): String {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val id = "ready_" + Integer.toHexString(p.soundUri.hashCode())
        if (nm.getNotificationChannel(id) == null) {
            val ch = NotificationChannel(id, "Báo AI hồi · ${p.soundName}", NotificationManager.IMPORTANCE_HIGH)
            ch.description = "Thông báo khi AI hồi xong"
            val sound = resolveSound(p.soundUri)
            if (sound == null) {
                ch.setSound(null, null)
                ch.enableVibration(false)
            } else {
                ch.setSound(
                    sound,
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                ch.enableVibration(true)
            }
            nm.createNotificationChannel(ch)
        }
        return id
    }

    fun notifyReady(ctx: Context, p: Project) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = ensureChannel(ctx, p)
        val open = PendingIntent.getActivity(
            ctx,
            p.id.hashCode(),
            Intent(ctx, MainActivity::class.java)
                .setAction(Consts.ACTION_OPEN_PROJECT)
                .putExtra(Consts.EXTRA_PROJECT_ID, p.id)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_stat_ai)
            .setContentTitle("${p.ai} đã hồi xong")
            .setContentText("Dự án: ${p.name}")
            .setCategory(Notification.CATEGORY_ALARM)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(p.id.hashCode(), n)
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getStringExtra(Consts.EXTRA_PROJECT_ID) ?: return
        val p = Store.load(context).firstOrNull { it.id == id } ?: return
        // Nếu người dùng đã dời giờ hồi sang tương lai thì bỏ qua báo thức cũ
        if (p.cooldownUntil > System.currentTimeMillis() + 30_000L) return
        Notifier.notifyReady(context, p)
        ProjectWidgetProvider.updateAll(context)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Alarms.rescheduleAll(context, Store.load(context))
        ProjectWidgetProvider.updateAll(context)
    }
}
