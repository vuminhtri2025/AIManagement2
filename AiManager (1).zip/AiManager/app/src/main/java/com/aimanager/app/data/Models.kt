package com.aimanager.app.data

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

const val DEFAULT_AI = "Claude"
val PRESET_AIS = listOf("Claude", "ChatGPT", "Gemini", "Grok", "DeepSeek", "Copilot", "Perplexity", "Cursor")

data class Todo(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val createdAt: Long = System.currentTimeMillis(),
    val done: Boolean = false
)

data class Project(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val ai: String = DEFAULT_AI,
    /** Thời điểm AI hồi xong (epoch ms). 0 = sẵn sàng. */
    val cooldownUntil: Long = 0L,
    /** "" = chuông thông báo mặc định, "silent" = im lặng, còn lại là Uri */
    val soundUri: String = "",
    val soundName: String = "Mặc định",
    val createdAt: Long = System.currentTimeMillis(),
    val todos: List<Todo> = emptyList()
) {
    val remaining: Int get() = todos.count { !it.done }
    val isDone: Boolean get() = remaining == 0
    fun isCooling(now: Long = System.currentTimeMillis()): Boolean = cooldownUntil > now
}

fun Todo.toJson(): JSONObject = JSONObject()
    .put("id", id)
    .put("text", text)
    .put("createdAt", createdAt)
    .put("done", done)

fun JSONObject.toTodo(): Todo = Todo(
    id = getString("id"),
    text = getString("text"),
    createdAt = optLong("createdAt", 0L),
    done = optBoolean("done", false)
)

fun Project.toJson(): JSONObject {
    val arr = JSONArray()
    todos.forEach { arr.put(it.toJson()) }
    return JSONObject()
        .put("id", id)
        .put("name", name)
        .put("ai", ai)
        .put("cooldownUntil", cooldownUntil)
        .put("soundUri", soundUri)
        .put("soundName", soundName)
        .put("createdAt", createdAt)
        .put("todos", arr)
}

fun JSONObject.toProject(): Project {
    val arr = optJSONArray("todos") ?: JSONArray()
    val todos = (0 until arr.length()).map { arr.getJSONObject(it).toTodo() }
    return Project(
        id = getString("id"),
        name = getString("name"),
        ai = optString("ai", DEFAULT_AI),
        cooldownUntil = optLong("cooldownUntil", 0L),
        soundUri = optString("soundUri", ""),
        soundName = optString("soundName", "Mặc định"),
        createdAt = optLong("createdAt", 0L),
        todos = todos
    )
}
