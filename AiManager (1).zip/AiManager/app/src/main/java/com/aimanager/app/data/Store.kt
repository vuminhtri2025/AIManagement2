package com.aimanager.app.data

import android.content.Context
import org.json.JSONArray

object Store {
    private const val PREF = "ai_manager_store"
    private const val KEY = "projects"

    fun load(ctx: Context): List<Project> {
        val raw = ctx.applicationContext
            .getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getString(KEY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { arr.getJSONObject(it).toProject() }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(ctx: Context, projects: List<Project>) {
        val arr = JSONArray()
        projects.forEach { arr.put(it.toJson()) }
        ctx.applicationContext
            .getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY, arr.toString())
            .apply()
    }
}
