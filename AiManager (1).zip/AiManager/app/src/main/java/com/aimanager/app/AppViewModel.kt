package com.aimanager.app

import android.app.Application
import android.content.Context
import android.content.Intent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.aimanager.app.data.Project
import com.aimanager.app.data.Store
import com.aimanager.app.data.Todo
import com.aimanager.app.widget.ProjectWidgetProvider

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Context get() = getApplication<Application>().applicationContext

    var projects by mutableStateOf(Store.load(app))
        private set
    var openProjectId by mutableStateOf<String?>(null)
    var requestedTab by mutableStateOf<Int?>(null)

    private fun commit(list: List<Project>) {
        projects = list
        Store.save(ctx, list)
        ProjectWidgetProvider.updateAll(ctx)
    }

    private fun change(id: String, f: (Project) -> Project): Project? {
        var result: Project? = null
        commit(projects.map { p ->
            if (p.id == id) f(p).also { result = it } else p
        })
        return result
    }

    fun addProject(name: String): String {
        val p = Project(name = name.trim().ifBlank { "Dự án mới" })
        commit(listOf(p) + projects)
        return p.id
    }

    fun rename(id: String, name: String) {
        if (name.isBlank()) return
        change(id) { it.copy(name = name.trim()) }
    }

    fun delete(id: String) {
        Alarms.cancel(ctx, id)
        commit(projects.filterNot { it.id == id })
        if (openProjectId == id) openProjectId = null
    }

    fun setAi(id: String, ai: String) {
        if (ai.isBlank()) return
        change(id) { it.copy(ai = ai.trim()) }
    }

    /** millis = 0 -> sẵn sàng; > now -> đang hồi tới thời điểm đó */
    fun setCooldown(id: String, millis: Long) {
        val updated = change(id) { it.copy(cooldownUntil = millis) }
        if (updated != null) Alarms.schedule(ctx, updated)
    }

    fun setSound(id: String, uri: String, name: String) {
        change(id) { it.copy(soundUri = uri, soundName = name) }
    }

    fun addTodo(id: String, text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        change(id) { it.copy(todos = listOf(Todo(text = t)) + it.todos) }
    }

    fun toggleTodo(id: String, todoId: String) {
        change(id) { p ->
            p.copy(todos = p.todos.map { if (it.id == todoId) it.copy(done = !it.done) else it })
        }
    }

    fun deleteTodo(id: String, todoId: String) {
        change(id) { p -> p.copy(todos = p.todos.filterNot { it.id == todoId }) }
    }

    fun handleIntent(intent: Intent?) {
        intent ?: return
        when (intent.action) {
            Consts.ACTION_OPEN_PROJECT -> {
                val id = intent.getStringExtra(Consts.EXTRA_PROJECT_ID)
                if (id != null && projects.any { it.id == id }) {
                    openProjectId = id
                } else {
                    openProjectId = null
                    requestedTab = 0
                }
            }
            Consts.ACTION_OPEN_TAB -> {
                openProjectId = null
                requestedTab = intent.getIntExtra(Consts.EXTRA_TAB, 0)
            }
        }
    }
}
