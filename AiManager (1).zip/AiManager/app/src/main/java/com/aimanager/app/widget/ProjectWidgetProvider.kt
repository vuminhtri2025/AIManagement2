package com.aimanager.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.RemoteViews
import com.aimanager.app.Consts
import com.aimanager.app.MainActivity
import com.aimanager.app.R
import com.aimanager.app.data.Store

class ProjectWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) pushLayout(context, appWidgetManager, id)
        appWidgetManager.notifyAppWidgetViewDataChanged(appWidgetIds, R.id.widget_list)
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: Bundle
    ) {
        pushLayout(context, appWidgetManager, appWidgetId)
        super.onAppWidgetOptionsChanged(context, appWidgetManager, appWidgetId, newOptions)
    }

    companion object {
        fun updateAll(context: Context) {
            val app = context.applicationContext
            val mgr = AppWidgetManager.getInstance(app)
            val ids = mgr.getAppWidgetIds(ComponentName(app, ProjectWidgetProvider::class.java))
            if (ids.isEmpty()) return
            for (id in ids) pushLayout(app, mgr, id)
            mgr.notifyAppWidgetViewDataChanged(ids, R.id.widget_list)
        }

        private fun pushLayout(context: Context, mgr: AppWidgetManager, widgetId: Int) {
            val views = RemoteViews(context.packageName, R.layout.widget_project)

            val pending = Store.load(context).count { !it.isDone }
            views.setTextViewText(
                R.id.widget_title,
                if (pending > 0) "Dự án đang chờ · $pending" else "Dự án đang chờ"
            )

            val svc = Intent(context, ProjectWidgetService::class.java).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
                data = Uri.parse(toUri(Intent.URI_INTENT_SCHEME))
            }
            views.setRemoteAdapter(R.id.widget_list, svc)
            views.setEmptyView(R.id.widget_list, R.id.widget_empty)

            // Bấm tên widget / vùng trống -> tab Dự án
            val openTab = PendingIntent.getActivity(
                context,
                1,
                Intent(context, MainActivity::class.java).apply {
                    action = Consts.ACTION_OPEN_TAB
                    putExtra(Consts.EXTRA_TAB, 0)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                },
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, openTab)
            views.setOnClickPendingIntent(R.id.widget_title, openTab)
            views.setOnClickPendingIntent(R.id.widget_empty, openTab)

            // Bấm 1 dự án -> vào thẳng trang dự án
            val template = PendingIntent.getActivity(
                context,
                2,
                Intent(context, MainActivity::class.java).apply {
                    action = Consts.ACTION_OPEN_PROJECT
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                },
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            )
            views.setPendingIntentTemplate(R.id.widget_list, template)

            mgr.updateAppWidget(widgetId, views)
        }
    }
}
