@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.aimanager.app.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SelectableDates
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aimanager.app.AppViewModel
import com.aimanager.app.data.Ai
import com.aimanager.app.data.Project
import com.aimanager.app.data.Todo
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZoneOffset

// ---------------------------------------------------------------- Root

@Composable
fun AppRoot(vm: AppViewModel) {
    val pagerState = rememberPagerState(pageCount = { 2 })
    val project = vm.projects.firstOrNull { it.id == vm.openProjectId }
    val editor = vm.todoEditor
    val editorProject = editor?.let { t -> vm.projects.firstOrNull { it.id == t.projectId } }
    val aiName = vm.openAi

    LaunchedEffect(vm.requestedTab) {
        val tab = vm.requestedTab
        if (tab != null) {
            pagerState.scrollToPage(tab.coerceIn(0, 1))
            vm.requestedTab = null
        }
    }

    Surface(Modifier.fillMaxSize(), color = AppColors.Black, contentColor = AppColors.Text) {
        if (editor != null && editorProject != null) {
            TodoEditorScreen(editorProject, editor.todoId, vm)
        } else if (project != null) {
            BackHandler { vm.openProjectId = null }
            DetailScreen(project, vm) { vm.openProjectId = null }
        } else if (aiName != null && vm.aiOf(aiName) != null) {
            BackHandler { vm.openAi = null }
            AiDetailScreen(aiName, vm) { vm.openAi = null }
        } else {
            HomeScreen(vm, pagerState)
        }
    }
}

// ---------------------------------------------------------------- Home (2 tab, vuốt qua lại)

@Composable
fun HomeScreen(vm: AppViewModel, pagerState: PagerState) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val now by rememberNow()
    var showAddProject by remember { mutableStateOf(false) }
    var showAddAi by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = AppColors.Black,
        floatingActionButton = {
            FloatingActionButton(
                onClick = { if (pagerState.currentPage == 0) showAddProject = true else showAddAi = true },
                containerColor = Color.White,
                contentColor = Color.Black,
                shape = CircleShape
            ) {
                Icon(
                    Icons.Default.Add,
                    contentDescription = if (pagerState.currentPage == 0) "Thêm dự án" else "Thêm AI"
                )
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 16.dp, bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Quản lý AI",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = { showSettings = true }) {
                    Icon(Icons.Default.Settings, contentDescription = "Cài đặt widget", tint = AppColors.Muted)
                }
            }
            TabRow(
                selectedTabIndex = pagerState.currentPage,
                containerColor = Color.Transparent,
                contentColor = Color.White
            ) {
                listOf("Dự án", "AI").forEachIndexed { index, title ->
                    Tab(
                        selected = pagerState.currentPage == index,
                        onClick = { scope.launch { pagerState.animateScrollToPage(index) } },
                        text = { Text(title, fontWeight = FontWeight.Medium) },
                        selectedContentColor = Color.White,
                        unselectedContentColor = AppColors.Muted
                    )
                }
            }
            HorizontalPager(
                state = pagerState,
                modifier = Modifier.weight(1f).fillMaxWidth()
            ) { page ->
                if (page == 0) ProjectsTab(vm, now) else AiTab(vm, now)
            }
        }
    }

    if (showSettings) {
        WidgetSettingsDialog(onDismiss = { showSettings = false })
    }
    if (showAddProject) {
        NameDialog(
            title = "Dự án mới",
            initial = "",
            confirmText = "Tạo",
            onConfirm = { name ->
                showAddProject = false
                vm.openProjectId = vm.addProject(name)
            },
            onDismiss = { showAddProject = false }
        )
    }
    if (showAddAi) {
        NameDialog(
            title = "AI mới",
            initial = "",
            confirmText = "Thêm",
            placeholder = "Tên AI",
            onConfirm = { name ->
                if (vm.addAi(name)) {
                    showAddAi = false
                } else {
                    Toast.makeText(ctx, "Tên AI đã tồn tại", Toast.LENGTH_SHORT).show()
                }
            },
            onDismiss = { showAddAi = false }
        )
    }
}

// ---------------------------------------------------------------- Tab 1: Dự án

@Composable
fun ProjectsTab(vm: AppViewModel, now: Long) {
    val sorted = sortedForDisplay(vm.projects, vm.ais.associate { it.name to it.cooldownUntil }, now)
    if (sorted.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Chưa có dự án nào.\nNhấn + để tạo dự án mới.", color = AppColors.Muted)
        }
        return
    }
    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(sorted, key = { it.id }) { p -> ProjectCard(p, now, vm) }
    }
}

/** Thẻ dự án gọn: Pending = đỏ, Done = xám nhẹ. Chỉ hiện thời gian còn lại của AI. */
@Composable
fun ProjectCard(p: Project, now: Long, vm: AppViewModel) {
    val pending = !p.isDone
    val shape = RoundedCornerShape(16.dp)
    val ai = vm.aiOf(p.ai)
    val cooling = ai?.isCooling(now) == true
    val sub = buildAnnotatedString {
        append(aiLabel(p.ai))
        if (ai != null) {
            append("  ·  ")
            withStyle(SpanStyle(color = if (cooling) AppColors.CooldownText else AppColors.ReadyText)) {
                append(if (cooling) fmtRemaining(ai.cooldownUntil, now) else "Sẵn sàng")
            }
        }
        append("  ·  ")
        append(if (pending) "${p.remaining} việc" else "Done")
    }
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = CARD_MIN_HEIGHT)
            .clip(shape)
            .background(if (pending) AppColors.PendingBg else AppColors.DoneBg)
            .border(1.dp, if (pending) AppColors.PendingBorder else AppColors.DoneBorder, shape)
            .clickable { vm.openProjectId = p.id }
            .padding(start = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f).padding(vertical = 8.dp)) {
            Text(
                p.name,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(2.dp))
            Text(
                sub,
                fontSize = 13.sp,
                color = Color.White.copy(alpha = 0.75f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        ProjectMenuButton(p, vm)
    }
}

/** Chiều cao tối thiểu chung cho thẻ dự án và thẻ AI để hai loại thẻ bằng nhau. */
private val CARD_MIN_HEIGHT = 60.dp

// ---------------------------------------------------------------- Tab 2: AI

@Composable
fun AiTab(vm: AppViewModel, now: Long) {
    if (vm.ais.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Chưa có AI nào.\nNhấn + để thêm AI của bạn.", color = AppColors.Muted)
        }
        return
    }
    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(vm.ais, key = { it.id }) { ai -> AiCard(ai, now, vm) }
    }
}

/** Thẻ AI: vàng khi đang hồi, xanh khi sẵn sàng. Trạng thái nằm bên phải. */
@Composable
fun AiCard(ai: Ai, now: Long, vm: AppViewModel) {
    val shape = RoundedCornerShape(16.dp)
    val cooling = ai.isCooling(now)
    val list = vm.projects.filter { it.ai == ai.name }
    val done = list.count { it.isDone }
    val pending = list.size - done
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = CARD_MIN_HEIGHT)
            .clip(shape)
            .background(if (cooling) AppColors.AiCoolBg else AppColors.AiReadyBg)
            .border(1.dp, if (cooling) AppColors.AiCoolBorder else AppColors.AiReadyBorder, shape)
            .clickable { vm.openAi = ai.name }
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                ai.name,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(2.dp))
            Text(
                "${list.size} dự án  ·  $done Done  ·  $pending Pending",
                fontSize = 13.sp,
                color = Color.White.copy(alpha = 0.75f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End) {
            Text(
                if (cooling) "Đang hồi" else "Sẵn sàng",
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White
            )
            if (cooling) {
                Text(
                    fmtRemaining(ai.cooldownUntil, now),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = AppColors.CooldownText
                )
            }
        }
    }
}

/** Trang của từng AI: công tắc Sẵn sàng / Đang hồi, các dự án AI đang đảm nhiệm, menu 3 chấm. */
@Composable
fun AiDetailScreen(aiName: String, vm: AppViewModel, onBack: () -> Unit) {
    val now by rememberNow()
    val ai = vm.aiOf(aiName) ?: return
    val list = sortedForDisplay(
        vm.projects.filter { it.ai == ai.name },
        vm.ais.associate { it.name to it.cooldownUntil },
        now
    )

    Column(
        Modifier
            .fillMaxSize()
            .background(AppColors.Black)
            .systemBarsPadding()
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Quay lại", tint = Color.White)
            }
            Text(
                ai.name,
                modifier = Modifier.weight(1f),
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            AiMenuButton(ai.name, vm)
        }
        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            item(key = "status") {
                val cooling = ai.isCooling(now)
                AppCard {
                    Text("Trạng thái AI", color = AppColors.Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(10.dp))
                    Row {
                        SegButton("Sẵn sàng", selected = !cooling, modifier = Modifier.weight(1f)) {
                            if (cooling) vm.setAiCooldown(ai.name, 0L)
                        }
                        Spacer(Modifier.width(8.dp))
                        SegButton("Đang hồi", selected = cooling, modifier = Modifier.weight(1f)) {
                            if (!cooling) vm.setAiCooldown(ai.name, defaultCooldown())
                        }
                    }
                    if (cooling) {
                        Spacer(Modifier.height(14.dp))
                        CooldownPickers(ai, vm, now)
                    }
                }
            }
            item(key = "head") {
                Text(
                    if (list.isEmpty()) "AI này chưa đảm nhiệm dự án nào."
                    else "Đang đảm nhiệm ${list.size} dự án",
                    color = AppColors.Muted,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(top = 6.dp, bottom = 2.dp)
                )
            }
            items(list, key = { it.id }) { p -> ProjectCard(p, now, vm) }
        }
    }
}

/** Ô chọn Ngày (lịch) + Giờ (đồng hồ kim, kéo) + dòng "hồi xong lúc..." của 1 AI. */
@Composable
private fun CooldownPickers(ai: Ai, vm: AppViewModel, now: Long) {
    val ctx = LocalContext.current
    val zone = ZoneId.systemDefault()
    var showDate by remember { mutableStateOf(false) }
    var showTime by remember { mutableStateOf(false) }

    fun applyCooldown(date: LocalDate, time: LocalTime) {
        val ms = date.atTime(time.withSecond(0).withNano(0)).atZone(zone).toInstant().toEpochMilli()
        if (ms <= System.currentTimeMillis()) {
            Toast.makeText(ctx, "Thời gian hồi phải ở tương lai", Toast.LENGTH_SHORT).show()
        } else {
            vm.setAiCooldown(ai.name, ms)
        }
    }

    Column {
        Row {
            PickerButton("Ngày", fmtFullDate(ai.cooldownUntil), Modifier.weight(1f)) { showDate = true }
            Spacer(Modifier.width(8.dp))
            PickerButton("Giờ", fmtTime(ai.cooldownUntil), Modifier.weight(1f)) { showTime = true }
        }
        Spacer(Modifier.height(10.dp))
        Text(
            "Hồi xong lúc ${fmtTime(ai.cooldownUntil)} · còn ${fmtRemaining(ai.cooldownUntil, now)}",
            color = AppColors.CooldownText,
            fontSize = 13.sp
        )
    }

    if (showDate && ai.isCooling(now)) {
        val current = Instant.ofEpochMilli(ai.cooldownUntil).atZone(zone)
        val todayUtc = LocalDate.now(zone).atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
        val state = rememberDatePickerState(
            initialSelectedDateMillis = current.toLocalDate().atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli(),
            selectableDates = object : SelectableDates {
                override fun isSelectableDate(utcTimeMillis: Long): Boolean = utcTimeMillis >= todayUtc
            }
        )
        DatePickerDialog(
            onDismissRequest = { showDate = false },
            confirmButton = {
                TextButton(onClick = {
                    val ms = state.selectedDateMillis
                    if (ms != null) {
                        val date = Instant.ofEpochMilli(ms).atZone(ZoneOffset.UTC).toLocalDate()
                        applyCooldown(date, current.toLocalTime())
                    }
                    showDate = false
                }) { Text("Chọn") }
            },
            dismissButton = { TextButton(onClick = { showDate = false }) { Text("Hủy") } }
        ) {
            DatePicker(state = state)
        }
    }

    if (showTime && ai.isCooling(now)) {
        val current = Instant.ofEpochMilli(ai.cooldownUntil).atZone(zone)
        ClockTimeDialog(
            initialHour = current.hour,
            initialMinute = current.minute,
            onConfirm = { h, m ->
                applyCooldown(current.toLocalDate(), LocalTime.of(h, m))
                showTime = false
            },
            onDismiss = { showTime = false }
        )
    }
}

// ---------------------------------------------------------------- Trang dự án

private fun defaultCooldown(): Long = (System.currentTimeMillis() / 60_000L) * 60_000L + 60L * 60_000L

@Composable
fun DetailScreen(project: Project, vm: AppViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val now by rememberNow()
    var showAi by remember { mutableStateOf(false) }

    val ai = vm.aiOf(project.ai)
    val cooling = ai?.isCooling(now) == true
    val todos = remember(project.todos) {
        project.todos.sortedWith(compareBy<Todo> { it.done }.thenByDescending { it.createdAt })
    }

    fun needAi() {
        Toast.makeText(ctx, "Hãy chọn AI cho dự án trước", Toast.LENGTH_SHORT).show()
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(AppColors.Black)
            .systemBarsPadding()
            .imePadding()
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Quay lại", tint = Color.White)
            }
            Text(
                project.name,
                modifier = Modifier.weight(1f),
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (project.isDone) Pill("Done", AppColors.Green) else Pill("Pending", AppColors.Red)
            ProjectMenuButton(project, vm, onDeleted = onBack)
        }

        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            // --- AI đang dùng (chạm tên để đổi) + công tắc nhỏ Sẵn sàng / Đang hồi (của AI)
            item(key = "ai") {
                AppCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(
                            Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { showAi = true }
                        ) {
                            Text("AI đang sử dụng · chạm để đổi", color = AppColors.Muted, fontSize = 12.sp)
                            Spacer(Modifier.height(2.dp))
                            Text(
                                aiLabel(project.ai),
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (project.ai.isBlank()) AppColors.Muted else AppColors.Text,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        MiniToggle(
                            cooling = cooling,
                            onReady = {
                                if (ai == null) needAi() else if (cooling) vm.setAiCooldown(ai.name, 0L)
                            },
                            onCooling = {
                                if (ai == null) needAi() else if (!cooling) vm.setAiCooldown(ai.name, defaultCooldown())
                            }
                        )
                    }
                    if (ai != null) {
                        if (cooling) {
                            Spacer(Modifier.height(14.dp))
                            CooldownPickers(ai, vm, now)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Trạng thái này dùng chung cho mọi dự án của ${ai.name}",
                            color = AppColors.Muted,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            // --- Todolist
            item(key = "todo_head") {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Việc cần làm", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Text("${project.remaining} còn lại", color = AppColors.Muted, fontSize = 13.sp)
                    }
                    Spacer(Modifier.height(10.dp))
                    AddTodoButton { vm.openTodoEditor(project.id, null) }
                }
            }
            if (todos.isEmpty()) {
                item(key = "todo_empty") {
                    Text("Chưa có việc nào.", color = AppColors.Muted, fontSize = 14.sp)
                }
            }
            items(todos, key = { it.id }) { t ->
                TodoRow(
                    t,
                    Modifier.animateItemPlacement(),
                    onOpen = { vm.openTodoEditor(project.id, t.id) },
                    onToggle = { vm.toggleTodo(project.id, t.id) }
                )
            }
        }
    }

    // --- Dialog đổi AI (chỉ gồm AI do bạn tự thêm)
    if (showAi) {
        AiPickerDialog(
            current = project.ai,
            options = vm.ais.map { it.name },
            onPick = { vm.assignAi(project.id, it); showAi = false },
            onDismiss = { showAi = false }
        )
    }
}

// ---------------------------------------------------------------- Màn hình nhập công việc (full màn hình)

@Composable
fun TodoEditorScreen(project: Project, todoId: String?, vm: AppViewModel) {
    val existing = todoId?.let { id -> project.todos.firstOrNull { it.id == id } }
    var title by remember(todoId) { mutableStateOf(existing?.text ?: "") }
    var note by remember(todoId) { mutableStateOf(existing?.note ?: "") }
    val focus = remember { FocusRequester() }

    fun close(save: Boolean) {
        if (save) vm.saveTodo(project.id, todoId, title, note)
        vm.closeTodoEditor()
    }

    BackHandler { close(true) }
    LaunchedEffect(todoId) {
        if (existing == null) focus.requestFocus()
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(AppColors.Black)
            .systemBarsPadding()
            .imePadding()
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { close(true) }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Lưu và quay lại", tint = Color.White)
            }
            TextField(
                value = title,
                onValueChange = { title = it },
                modifier = Modifier.weight(1f).focusRequester(focus),
                singleLine = true,
                placeholder = { Text("Tiêu đề", fontSize = 22.sp, fontWeight = FontWeight.Bold) },
                textStyle = TextStyle(fontSize = 22.sp, fontWeight = FontWeight.Bold),
                colors = plainFieldColors()
            )
            if (existing != null) {
                IconButton(onClick = {
                    vm.deleteTodo(project.id, existing.id)
                    close(false)
                }) {
                    Icon(Icons.Default.Delete, contentDescription = "Xóa công việc", tint = AppColors.Muted)
                }
            }
            IconButton(onClick = { close(true) }) {
                Icon(Icons.Default.Check, contentDescription = "Lưu", tint = Color.White)
            }
        }
        Hairline()
        TextField(
            value = note,
            onValueChange = { note = it },
            modifier = Modifier.weight(1f).fillMaxWidth(),
            placeholder = { Text("Nội dung công việc…", fontSize = 16.sp) },
            textStyle = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
            colors = plainFieldColors()
        )
    }
}

// ---------------------------------------------------------------- Thành phần nhỏ

@Composable
private fun SegButton(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier
            .height(44.dp)
            .clip(shape)
            .background(if (selected) Color.White else Color.Transparent)
            .border(1.dp, if (selected) Color.White else AppColors.Outline, shape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            color = if (selected) Color.Black else AppColors.Text,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
private fun MiniToggle(cooling: Boolean, onReady: () -> Unit, onCooling: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Row(
        Modifier
            .clip(shape)
            .border(1.dp, AppColors.Outline, shape)
    ) {
        MiniSeg("Sẵn sàng", selected = !cooling, onClick = onReady)
        MiniSeg("Đang hồi", selected = cooling, onClick = onCooling)
    }
}

@Composable
private fun MiniSeg(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .background(if (selected) Color.White else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 7.dp)
    ) {
        Text(
            label,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            color = if (selected) Color.Black else AppColors.Muted
        )
    }
}

@Composable
private fun PickerButton(label: String, value: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Column(
        modifier
            .clip(shape)
            .background(AppColors.CardHigh)
            .border(1.dp, AppColors.Outline, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        Text(label, color = AppColors.Muted, fontSize = 12.sp)
        Spacer(Modifier.height(2.dp))
        Text(value, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun AddTodoButton(onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .border(1.dp, AppColors.Outline, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Add, contentDescription = null, tint = Color.White)
        Spacer(Modifier.width(10.dp))
        Text("Thêm công việc", color = AppColors.Muted)
    }
}

@Composable
private fun TodoRow(t: Todo, modifier: Modifier, onOpen: () -> Unit, onToggle: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(AppColors.Card)
            .border(1.dp, AppColors.Outline, shape)
            .clickable(onClick = onOpen)
            .padding(start = 6.dp, end = 12.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(
            checked = t.done,
            onCheckedChange = { onToggle() },
            colors = CheckboxDefaults.colors(
                checkedColor = Color.White,
                checkmarkColor = Color.Black,
                uncheckedColor = AppColors.Muted
            )
        )
        Column(Modifier.weight(1f).padding(horizontal = 4.dp, vertical = 4.dp)) {
            Text(
                t.text,
                fontSize = 15.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                color = if (t.done) AppColors.Muted else AppColors.Text,
                textDecoration = if (t.done) TextDecoration.LineThrough else null
            )
            if (t.note.isNotBlank() && t.note != t.text) {
                Text(
                    t.note.replace('\n', ' '),
                    fontSize = 13.sp,
                    color = AppColors.Muted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Text(fmtDateTime(t.createdAt), color = AppColors.Muted, fontSize = 11.sp)
        }
    }
}
