# Giữ số dòng để đọc được stacktrace khi crash
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# ViewModel được tạo bằng reflection (constructor nhận Application)
-keep class com.aimanager.app.AppViewModel { <init>(android.app.Application); }

# Receiver / Service / Activity đã được giữ tự động nhờ AndroidManifest.
