package com.aimanager.app.ui

import com.aimanager.app.data.Project

/**
 * Thứ tự hiển thị thẻ dự án:
 * 1. Dự án Pending ở trên, Done ở dưới.
 * 2. Trong nhóm Pending: AI sẵn sàng trước, rồi tới AI đang hồi (gần hồi xong nhất lên trước),
 *    cuối cùng là dự án chưa chọn AI. Cùng mức thì dự án mới tạo lên trước.
 *
 * @param cooldowns tên AI -> thời điểm hồi xong (0 = sẵn sàng)
 */
fun sortedForDisplay(projects: List<Project>, cooldowns: Map<String, Long>, now: Long): List<Project> {
    fun rank(p: Project): Int = when {
        p.isDone -> 0
        p.ai.isBlank() || !cooldowns.containsKey(p.ai) -> 2
        (cooldowns[p.ai] ?: 0L) > now -> 1
        else -> 0
    }
    fun cooldown(p: Project): Long = if (rank(p) == 1) cooldowns[p.ai] ?: 0L else 0L

    return projects.sortedWith(
        compareBy<Project> { it.isDone }
            .thenBy { rank(it) }
            .thenBy { cooldown(it) }
            .thenByDescending { it.createdAt }
    )
}
