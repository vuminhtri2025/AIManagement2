package com.aimanager.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object AppColors {
    val Black = Color(0xFF000000)
    val Card = Color(0xFF111111)
    val CardHigh = Color(0xFF1A1A1A)
    val Outline = Color(0xFF262626)
    val Text = Color(0xFFF2F2F2)
    val Muted = Color(0xFF8A8A8A)
    val Green = Color(0xFF4ADE80)
    val Amber = Color(0xFFFBBF24)
    val Orange = Color(0xFFFB923C)
    val Red = Color(0xFFF87171)

    // Thẻ dự án: Pending = đỏ, Done = xám nhẹ
    val PendingGradient = listOf(Color(0xFFD93636), Color(0xFF7A1212))
    val DoneGradient = listOf(Color(0xFF555555), Color(0xFF2E2E2E))
    val PendingBg = Color(0xFF6B1B1B)
    val PendingBorder = Color(0xFFEF6A6A)
    val DoneBg = Color(0xFF262626)
    val DoneBorder = Color(0xFF6A6A6A)
    // Thẻ AI: đang hồi = vàng, sẵn sàng = xanh
    val AiCoolBg = Color(0xFF6B5A10)
    val AiCoolBorder = Color(0xFFB89A1C)
    val AiReadyBg = Color(0xFF14532D)
    val AiReadyBorder = Color(0xFF22874A)
    val CooldownText = Color(0xFFFFD166)
    val ReadyText = Color(0xFF86EFAC)
}

private val Scheme = darkColorScheme(
    primary = Color.White,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF2A2A2A),
    onPrimaryContainer = Color.White,
    secondary = Color(0xFFCFCFCF),
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF242424),
    onSecondaryContainer = AppColors.Text,
    background = AppColors.Black,
    onBackground = AppColors.Text,
    surface = AppColors.Black,
    onSurface = AppColors.Text,
    surfaceVariant = AppColors.CardHigh,
    onSurfaceVariant = AppColors.Muted,
    surfaceTint = Color.Transparent,
    outline = AppColors.Outline,
    outlineVariant = AppColors.Outline,
    error = AppColors.Red,
    surfaceContainerLowest = Color(0xFF000000),
    surfaceContainerLow = Color(0xFF0B0B0B),
    surfaceContainer = Color(0xFF111111),
    surfaceContainerHigh = Color(0xFF161616),
    surfaceContainerHighest = Color(0xFF1E1E1E)
)

@Composable
fun AiManagerTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, typography = Typography(), content = content)
}
