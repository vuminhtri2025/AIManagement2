package com.aimanager.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import android.provider.Settings
import com.aimanager.app.data.Ai
import com.aimanager.app.data.Project
import com.aimanager.app.data.Store
import com.aimanager.app.widget.ProjectWidgetProvider

/** Báo thức theo AI: khi AI hồi xong thì báo. */
object Alarms {
    fun schedule(ctx: Context, ai: Ai) {
        val app = ctx.applicationContext
        cancel(app, ai.id)
        if (ai.cooldownUntil <= System.currentTimeMillis()) return
        val am = app.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pendingFor(app, ai.id)
        try {
            val canExact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()
            if (canExact) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ai.cooldownUntil, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ai.cooldownUntil, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ai.cooldownUntil, pi)
        }
    }

    fun cancel(ctx: Context, aiId: String) {
        val app = ctx.applicationContext
        val am = app.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pendingFor(app, aiId))
    }

    fun rescheduleAll(ctx: Context, ais: List<Ai>) {
        ais.forEach { schedule(ctx, it) }
    }

    private fun pendingFor(ctx: Context, aiId: String): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java)
            .setAction(Consts.ACTION_AI_READY)
            .putExtra(Consts.EXTRA_AI_ID, aiId)
        return PendingIntent.getBroadcast(
            ctx,
            aiId.hashCode(),
            i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}

object Notifier {
    fun resolveSound(uri: String): Uri? = when (uri) {
        Consts.SOUND_SILENT -> null
        "" -> Settings.System.DEFAULT_NOTIFICATION_URI
        else -> Uri.parse(uri)
    }

    private fun ensureChannel(ctx: Context, soundUri: String, soundName: String): String {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val id = "ready_" + Integer.toHexString(soundUri.hashCode())
        if (nm.getNotificationChannel(id) == null) {
            val ch = NotificationChannel(id, "Báo AI hồi · $soundName", NotificationManager.IMPORTANCE_HIGH)
            ch.description = "Thông báo khi AI hồi xong"
            val sound = resolveSound(soundUri)
            if (sound == null) {
                ch.setSound(null, null)
                ch.enableVibration(false)
            } else {
                ch.setSound(
                    sound,
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                ch.enableVibration(true)
            }
            nm.createNotificationChannel(ch)
        }
        return id
    }

    /**
     * Báo AI đã hồi xong. Chuông lấy theo dự án đang chờ (Pending) mới nhất của AI này;
     * không có dự án nào thì dùng chuông mặc định.
     */
    fun notifyReady(ctx: Context, ai: Ai, projects: List<Project>) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val pending = projects
            .filter { it.ai == ai.name && !it.isDone }
            .sortedByDescending { it.createdAt }
        val first = pending.firstOrNull()
        val channel = ensureChannel(ctx, first?.soundUri ?: "", first?.soundName ?: "Mặc định")
        val open = PendingIntent.getActivity(
            ctx,
            ai.id.hashCode(),
            Intent(ctx, MainActivity::class.java)
                .setAction(Consts.ACTION_OPEN_AI)
                .putExtra(Consts.EXTRA_AI_ID, ai.id)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val text = if (pending.isEmpty()) "Sẵn sàng làm việc" else "Dự án: " + pending.joinToString(", ") { it.name }
        val n = Notification.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_stat_ai)
            .setContentTitle("${ai.name} đã hồi xong")
            .setContentText(text)
            .setCategory(Notification.CATEGORY_ALARM)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(ai.id.hashCode(), n)
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getStringExtra(Consts.EXTRA_AI_ID) ?: return
        val projects = Store.load(context)
        val ai = Store.loadAis(context, projects).firstOrNull { it.id == id } ?: return
        // Nếu người dùng đã dời giờ hồi sang tương lai thì bỏ qua báo thức cũ
        if (ai.cooldownUntil > System.currentTimeMillis() + 30_000L) return
        Notifier.notifyReady(context, ai, projects)
        ProjectWidgetProvider.updateAll(context)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val projects = Store.load(context)
        Alarms.rescheduleAll(context, Store.loadAis(context, projects))
        ProjectWidgetProvider.updateAll(context)
    }
}
