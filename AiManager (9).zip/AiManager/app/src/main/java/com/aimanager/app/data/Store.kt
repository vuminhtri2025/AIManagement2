package com.aimanager.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

object Store {
    private const val PREF = "ai_manager_store"
    private const val KEY = "projects"
    private const val KEY_AIS = "ais"
    private const val KEY_WIDGET_TRANSPARENCY = "widget_transparency"

    fun load(ctx: Context): List<Project> {
        val raw = ctx.applicationContext
            .getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getString(KEY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { arr.getJSONObject(it).toProject() }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(ctx: Context, projects: List<Project>) {
        val arr = JSONArray()
        projects.forEach { arr.put(it.toJson()) }
        ctx.applicationContext
            .getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY, arr.toString())
            .apply()
    }

    /**
     * Danh sách AI (kèm trạng thái hồi). Tự chuyển dữ liệu cũ:
     * danh sách tên AI dạng chuỗi và giờ hồi theo từng dự án -> giờ hồi theo AI.
     */
    fun loadAis(ctx: Context, projects: List<Project>): List<Ai> {
        val raw = ctx.applicationContext
            .getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getString(KEY_AIS, null)
        val result = mutableListOf<Ai>()
        var migrated = false
        val now = System.currentTimeMillis()

        fun legacyCooldown(name: String): Long =
            projects.filter { it.ai.equals(name, ignoreCase = true) }
                .maxOfOrNull { it.cooldownUntil }
                ?.takeIf { it > now } ?: 0L

        if (raw != null) {
            try {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val item = arr.get(i)
                    if (item is JSONObject) {
                        val n = item.optString("name", "").trim()
                        if (n.isNotEmpty() && result.none { it.name.equals(n, ignoreCase = true) }) {
                            var id = item.optString("id", "")
                            if (id.isBlank()) {
                                id = UUID.randomUUID().toString()
                                migrated = true
                            }
                            result.add(Ai(id = id, name = n, cooldownUntil = item.optLong("cooldownUntil", 0L)))
                        }
                    } else {
                        val n = arr.getString(i).trim()
                        if (n.isNotEmpty() && result.none { it.name.equals(n, ignoreCase = true) }) {
                            result.add(Ai(name = n, cooldownUntil = legacyCooldown(n)))
                            migrated = true
                        }
                    }
                }
            } catch (e: Exception) {
                // bỏ qua dữ liệu hỏng
            }
        }
        for (p in projects) {
            val n = p.ai.trim()
            if (n.isNotEmpty() && result.none { it.name.equals(n, ignoreCase = true) }) {
                result.add(Ai(name = n, cooldownUntil = legacyCooldown(n)))
                migrated = true
            }
        }
        if (migrated) saveAis(ctx, result)
        return result
    }

    fun saveAis(ctx: Context, ais: List<Ai>) {
        val arr = JSONArray()
        ais.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("name", it.name)
                    .put("cooldownUntil", it.cooldownUntil)
            )
        }
        ctx.applicationContext
            .getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_AIS, arr.toString())
            .apply()
    }

    /** Độ trong suốt nền widget: 0 = đặc, 100 = trong suốt hoàn toàn. */
    fun widgetTransparency(ctx: Context): Int =
        ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getInt(KEY_WIDGET_TRANSPARENCY, 5)
            .coerceIn(0, 100)

    fun setWidgetTransparency(ctx: Context, percent: Int) {
        ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_WIDGET_TRANSPARENCY, percent.coerceIn(0, 100))
            .apply()
    }
}
